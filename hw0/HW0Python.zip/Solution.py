class Solution:

    def __init__(self, ip):
        """
            The constructor exists only to initialize variables. You do not need to change it.
            :param ip: input list that consists of n element from {A,B}
        """
        self.inputList = ip

    def outputSortedList(self, A, B, n):
        
        return None
